package com.garageplug.AmaznCart.ServiceImpl;

import com.garageplug.AmaznCart.Model.Discount;
import com.garageplug.AmaznCart.Model.Product;
import com.garageplug.AmaznCart.Repository.ProductRepository;
import com.garageplug.AmaznCart.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    RestTemplate restTemplate;
    @Override
    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public void deleteProduct(Long productId) {
        productRepository.deleteById(productId);
    }

    @Override
    public List<Product> getProducts(String promotionSet) {
        List<Product> products = productRepository.findAll();
        products.forEach(this::convertPriceToINR);

        products.forEach(product -> applyPromotion(product, promotionSet));

        return products;
    }

    private void convertPriceToINR(Product product) {
        if(!product.getCurrency().equals("INR")){
            String url = "https://api.exchangeratesapi.io/latest?base=" + product.getCurrency();
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            Map<String, Double> rates = (Map<String, Double>) response.getBody().get("rates");
            Double inrRate = rates.get("INR");
            product.setPrice(product.getPrice()*inrRate);
            product.setCurrency("INR");
        }
    }

    private void applyPromotion(Product product, String promotionSet) {
        double originalPrice = product.getPrice();
        double discount = 0.0;
        String discountTag = "";
        if ("SetA".equals(promotionSet)) {
            // Apply Promotion Set A
            if ("UAE".equals(product.getOrigin())) {
                discount = originalPrice * 0.06;
                discountTag = "6% off";
            }
            if (product.getRating() == 2) {
                double ratingDiscount = originalPrice * 0.04;
                if (ratingDiscount > discount) {
                    discount = ratingDiscount;
                    discountTag = "4% off";
                }
            } else if (product.getRating() < 2) {
                double ratingDiscount = originalPrice * 0.08;
                if (ratingDiscount > discount) {
                    discount = ratingDiscount;
                    discountTag = "8% off";
                }
            }
            if (("electronics".equals(product.getCategory()) || "furnishing".equals(product.getCategory())) && originalPrice >= 500) {
                if (100 > discount) {
                    discount = 100;
                    discountTag = "Flat Rs 100 off";
                }
            }
        } else if ("SetB".equals(promotionSet)) {
            // Apply Promotion Set B
            if (product.getInventory() > 20) {
                discount = originalPrice * 0.12;
                discountTag = "12% off";
            }
            if (product.isNew()) {
                double newDiscount = originalPrice * 0.07;
                if (newDiscount > discount) {
                    discount = newDiscount;
                    discountTag = "7% off";
                }
            }
        }

        // Apply default discount if no other discount applied
        if (discount == 0.0 && originalPrice > 1000) {
            discount = originalPrice * 0.02;
            discountTag = "2% off";
        }

        // Adjust price and set discount information
        product.setPrice(originalPrice - discount);
        product.setDiscount(new Discount(discount, discountTag));
    }
}
