package com.garageplug.AmaznCart.Service;

import com.garageplug.AmaznCart.Model.Product;

import java.util.List;

public interface ProductService {
    Product saveProduct(Product product);

    void deleteProduct(Long productId);

    List<Product> getProducts(String promotion);
}
