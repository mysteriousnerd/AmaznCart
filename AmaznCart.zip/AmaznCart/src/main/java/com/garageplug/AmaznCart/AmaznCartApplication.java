package com.garageplug.AmaznCart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmaznCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmaznCartApplication.class, args);
	}
}
