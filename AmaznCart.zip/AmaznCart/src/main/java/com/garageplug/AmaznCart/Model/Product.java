package com.garageplug.AmaznCart.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String product;
    private String category;
    private String origin;
    private int inventory;
    private double rating;
    private String currency;
    private double price;
    private boolean isNew;
    @Embedded
    private Discount discount;
}
